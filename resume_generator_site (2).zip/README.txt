README - Resume Generator (Kazakh/Russian voice input)
-------------------------------------------------------
Files:
- index.html  — негізгі веб-бет. Оны GitHub Pages немесе кез келген статикалық хостингке жүктеңіз.

How to use:
1) Open index.html in browser (Google Chrome recommended).
2) Choose language (kk-KZ for Kazakh or ru-RU for Russian).
3) Use microphone buttons to dictate fields.
4) Press "Резюме құру", then "PDF жүктеу" to save the resume as PDF.

Notes:
- Web Speech API may not be supported in all browsers. Chrome works best.
- html2pdf is loaded from CDN; internet is required for PDF generation in-browser.
- For fully offline usage include html2pdf.min.js locally.

GitHub Pages deployment:
1) Create GitHub account.
2) Create a public repository.
3) Upload index.html.
4) Settings → Pages → Source: main branch, / (root) → Save.
5) Access site at: https://YOUR_LOGIN.github.io/REPO_NAME/

Author: Assistant
